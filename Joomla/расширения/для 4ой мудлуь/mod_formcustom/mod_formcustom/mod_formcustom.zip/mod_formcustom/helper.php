<?php
defined("_JEXEC") or die();
<button onclick="onButtonClick()" >Contact Form</button>
        <div id="form">
            <form class="contact-form">
                Имя пользователя: 
                <br>
                <input type="text" name="username" >
                <br>
                Тема обращения:
                <br>
                <input type="text" name="theme">
                <br>
                Текст сообщения:
                <br>
                <input type="text" name="message" style="height:15%">
                <br>
                <input type="button" value="Отправить">
            </form>
        </div>
