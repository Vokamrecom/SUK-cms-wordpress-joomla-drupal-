<?php
defined("_JEXEC") or die();

//require_once __DIR__.'/helper.php';

$document = JFactory::getDocument(); 
$document->addStyleSheet(__DIR__. '/assets/css/style.css');
$document->addScript(__DIR__.'/assets/js/script.js');

$class_sfx = htmlspecialchars($params->get('class_sfx'));

require JModuleHelper::getLayoutPath('mod_formcustom', $params->get('layout', 'default'));
?>