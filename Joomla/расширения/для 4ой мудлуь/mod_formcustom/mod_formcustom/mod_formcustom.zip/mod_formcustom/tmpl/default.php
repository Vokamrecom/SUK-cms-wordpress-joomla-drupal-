<?php
defined("_JEXEC") or die();

$document = JFactory::getDocument(); 
$document->addStyleSheet(__DIR__. '/assets/css/style.css');
$document->addScript(__DIR__.'/assets/js/script.js');
?>
<div class="user-module<?php echo $moduleclass_sfx; ?>">
Hello
</div>
