# DD_J_plg_system_google_analytics
is a Joomla! system plugin to add the Google - Analytics Tracking snipped to your site.

[![GPL Licence](https://badges.frapsoft.com/os/gpl/gpl.png?v=102)](https://opensource.org/licenses/GPL-2.0/)  

Analytics.google.com provides website analytics, this plugin implements that services by adding a JavaScript Tracking snipped to the head of your website.<br>

Google Website Property-ID (UA number) must be specified at plugin settings to connect your Website properly.

By default it is setup for **EU Privacy**. This means the **IP anonymization** mode ('set anonymizeIp true' script addition), Google will truncate/anonymize the last octet of the IP address on this mode. Recommended for Member States of the European Union as well as for other parties to the Agreement on the European Economic Area.
If you don't wish the EU Privacy mode, IP anonimization can also be specified at plugin settings.

This Plugin supports also Google Analytics Opt-Out Cookie through gaOptout() function.
The function can be triggered by a simple link to the function:

    <a href="javascript:gaOptout()">Disable Google Analytics</a>

Please take note of the privacy policy of your country. We provide no liability for legal correctness!

# System requirements
Joomla 3.x +                                                                                <br>
PHP 5.6.13 or newer is recommended.

# DD_ Namespace
DD_ stands for  **D**idl**d**u e.K. | HR IT-Solutions (Brand recognition)                   <br>
It is a namespace prefix, provided to avoid element name conflicts.

<br>
Author: HR IT-Solutions Florian Häusler https://www.hr-it-solution.com                      <br>
Copyright: (C) 2011 - 2017 Didldu e.K. | HR IT-Solutions                                    <br>
http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
