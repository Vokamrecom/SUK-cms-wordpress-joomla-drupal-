<?php
/*------------------------------------------------------------------------

# MOD_TZ_NEW_PRO Extension

# ------------------------------------------------------------------------

# author    tuyennv

# copyright Copyright (C) 2013 templaza.com. All Rights Reserved.

# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL

# Websites: http://www.templaza.com

# Technical Support:  Forum - http://templaza.com/Forum

-------------------------------------------------------------------------*/

// no direct access
defined('_JEXEC') or die;


if ($content == 'tz_portfolio') {
    JLoader::import('com_tz_portfolio.helpers.route', JPATH_SITE);
} else {
    JLoader::import('com_content.helpers.route', JPATH_SITE);
}
//require_once(JPATH_SITE . '/libraries/tzm/sources/modules/modules.php');
JLoader::import('libraries.tzm.sources.modules.modules',JPATH_SITE);
jimport('joomla.application.component.model');
//JLoader::import('libraries.HTTPFetcher',JPATH_COMPONENT_ADMINISTRATOR);
//JLoader::import('libraries.readfile',JPATH_COMPONENT_ADMINISTRATOR);

JModelLegacy::addIncludePath(JPATH_SITE . '/components/com_tz_portfolio/models', 'TZ_PortfolioModel');
$url = JURI::base();

abstract class modTzNewsHelper
{

    /*
     * Method get data
    */
    public static function getList(&$params)
    {
        $db = JFactory::getDbo();
        $content = $params->get('manager');
        $order = $params->get('order');
        $orderby = $params->get('orderby');
        $limit = $params->get('limit');
        $catids = $params->get('catid');
        $img = $params->get('image');
        $typenews = $params->get('views');
        $featureol = $params->get('show_featured');
        $redirect = $params->get('redirect_page');
        $show_audio = $params->get('show_audio');
        $show_quote = $params->get('show_quote');
        $show_link = $params->get('show_link');
        $dispatcher = JDispatcher::getInstance();
        $li = array();
//        require_once(JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'libraries' . DIRECTORY_SEPARATOR . 'HTTPFetcher.php');
//        require_once(JPATH_COMPONENT_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'libraries' . DIRECTORY_SEPARATOR . 'readfile.php');
        JLoader::import('libraries.HTTPFetcher',JPATH_COMPONENT_ADMINISTRATOR);
JLoader::import('libraries.readfile',JPATH_COMPONENT_ADMINISTRATOR);
        $fetch = new Services_Yadis_PlainHTTPFetcher();
        $threadLink = null;
        $comments = null;
        if ($show_audio == 0) {
            $li[] = "'audio'";
        }
        if ($show_quote == 0) {
            $li[] = "'quote'";
        }
        if ($show_link == 0) {
            $li[] = "'link'";
        }
        $li_arr = implode(",", $li);
        $where_a = '(tz_xc.type not in(' . $li_arr . ') or tz_xc.type is null)';
        // portfolio and content
        if ($typenews == "featured") {
            if (isset($catids) && !empty($catids)) {
                $catid = implode(",", $catids);
                $where = " ct.catid IN($catid) and ct.state = 1  and ct.featured = 1 ORDER BY ct.$orderby $order LIMIT $limit";
            } else {
                $where = " ct.state = 1 and ct.featured = 1 ORDER BY ct.$orderby $order LIMIT $limit";
            }
        } else {
            if (isset($catids) && !empty($catids)) {
                $catid = implode(",", $catids);
                if ($featureol == 1) {
                    $where = " ct.catid IN($catid) and ct.state = 1 and ct.featured = 1 ORDER BY ct.$orderby $order LIMIT $limit";
                } else {
                    $where = " ct.catid IN($catid) and ct.state = 1  ORDER BY ct.$orderby $order LIMIT $limit";
                }
            } else {
                $where = " ct.state = 1 ORDER BY ct.$orderby $order LIMIT $limit";
            }
        }

        if ($content == 'tz_portfolio') {
            $jquery = $db->getQuery(true);
            $jquery->select('ct.*');
            $jquery->from('#__content as ct');
            $jquery->select('cat.title as category_title,cat.id  as category_id, cat.alias as category_alias');
            $jquery->join('left', '#__categories as cat on cat.id = ct.catid');
            $jquery->select('us.id as user_id,us.name as author');
            $jquery->join('left', '#__users as us on us.id = ct.created_by');
            $jquery->select('tz_xc.type as type_media,tz_xc.id as tz_xc_id ,tz_xc.*');
            $jquery->join('left', '#__tz_portfolio_xref_content as tz_xc on tz_xc.contentid = ct.id');
            if ($li) {
                $jquery->where($where_a);
            }
            $jquery->where($where);
            $db->setQuery($jquery);
            $items = $db->loadObjectList();
            $param_com = JComponentHelper::getComponent('com_content')->params;
            if ($items) {
                foreach ($items as $i => $item) {

                    $item->text = $item->introtext;
                    JPluginHelper::importPlugin('content');
                    $results = $dispatcher->trigger('onContentPrepare', array('com_tz_portfolio.article', &$item, &$param_com, 0));
                    $item->introtext = $item->text;
                    $item->event = new stdClass();
                    $results = $dispatcher->trigger('onContentAfterTitle', array('com_tz_portfolio.article', &$item, &$param_com, 0));
                    $item->event->afterDisplayTitle = trim(implode("\n", $results));
                    $results = $dispatcher->trigger('onContentBeforeDisplay', array('com_tz_portfolio.article', &$item, &$param_com, 0));
                    $item->event->beforeDisplayContent = trim(implode("\n", $results));
                    $results = $dispatcher->trigger('onContentAfterDisplay', array('com_tz_portfolio.article', &$item, &$param_com, 0));
                    $item->event->afterDisplayContent = trim(implode("\n", $results));
                    //Get Plugins Model
                    $pmodel = JModelLegacy::getInstance('Plugins', 'TZ_PortfolioModel', array('ignore_request' => true));
                    //Get plugin Params for this article
                    $pmodel->setState('filter.contentid', $item->id);
                    $pluginParams = $pmodel->getParams();
                    $item->pluginparams = clone($pluginParams);
                    JPluginHelper::importPlugin('tz_portfolio');
                    $results = $dispatcher->trigger('onTZPluginPrepare', array('com_tz_portfolio.article', &$item, &$param_com, &$pluginParams, 0));
                    $results = $dispatcher->trigger('onTZPluginAfterTitle', array('com_tz_portfolio.article', &$item, &$param_com, &$pluginParams, 0));
                    $item->event->TZafterDisplayTitle = trim(implode("\n", $results));
                    $results = $dispatcher->trigger('onTZPluginBeforeDisplay', array('com_tz_portfolio.article', &$item, &$param_com, &$pluginParams, 0));
                    $item->event->TZbeforeDisplayContent = trim(implode("\n", $results));
                    $results = $dispatcher->trigger('onTZPluginAfterDisplay', array('com_tz_portfolio.article', &$item, &$param_com, &$pluginParams, 0));
                    $item->event->TZafterDisplayContent = trim(implode("\n", $results));
                    $item->media = null;
                    $item->tztitle = $item->title;
                    $item->hit = $item->hits;
                    echo $item->event->beforeDisplayContent;
                    echo $item->event->TZbeforeDisplayContent;
                    $item->intro = $item->introtext;
                    echo $item->event->afterDisplayContent;
                    echo $item->event->TZafterDisplayContent;
                    $item->slug = $item->contentid . ':' . $item->alias;
                    $item->catslug = $item->catid . ':' . $item->category_alias;
                    $item->category = $item->category_title;
                    $item->author = $item->author;
                    if ($redirect == 0) {
                        $item->link = JRoute::_(TZ_PortfolioHelperRoute::getArticleRoute($item->slug, $item->catslug));
                        $item->fullLink = JRoute::_(TZ_PortfolioHelperRoute::getArticleRoute($item->slug, $item->catslug), true, -1);
                    }
                    if ($redirect == 1) {
                        $item->link = JRoute::_(TZ_PortfolioHelperRoute::getPortfolioArticleRoute($item->slug, $item->catslug));
                        $item->fullLink = JRoute::_(TZ_PortfolioHelperRoute::getPortfolioArticleRoute($item->slug, $item->catslug), true, -1);
                    }
                    if (isset($item->type_media) and $item->type_media and $item->type_media != 'none') {

                        if ($item->type_media == 'image') {
                            $images = $item->images;
                            if ($images) {
                                $nameimg = JFile::getExt($images);
                                $count = strlen($nameimg);
                                $image_name = substr($images, 0, -($count + 1));
                                $item->image = $image_name . '_' . $img . '.' . $nameimg;
                            } else $item->image = '';
                        }
                        if ($item->type_media == 'imageGallery') {
                            $images = $item->gallery;
                            if ($images) {
                                $arrimages = explode("///", $images);
                                if ($arrimages[0]) {
                                    $nameimg = JFile::getExt($arrimages[0]);
                                    $count = strlen($nameimg);
                                    $image_name = substr($arrimages[0], 0, -($count + 1));
                                    $item->image = $image_name . '_' . $img . '.' . $nameimg;
                                }
                            } else $item->image = '';
                        }
                        if ($item->type_media == 'video') {
                            $images = $item->videothumb;
                            if ($images) {
                                $nameimg = JFile::getExt($images);
                                $count = strlen($nameimg);
                                $image_name = substr($images, 0, -($count + 1));
                                $item->image = $image_name . '_' . $img . '.' . $nameimg;
                            } else $item->image = '';
                        }
                        if ($item->type_media == 'audio') {
                            $images = $item->audiothumb;
                            if ($images) {
                                $nameimg = JFile::getExt($images);
                                $count = strlen($nameimg);
                                $image_name = substr($images, 0, -($count + 1));
                                $item->image = $image_name . '_' . $img . '.' . $nameimg;
                            } else $item->image = '';
                        }
                    } else {
                        $item->image = '';
                    }

                    if ($params->get('tz_show_count_comment', 1) == 1) {
                        if ($params->get('tz_comment_type', 'disqus') == 'disqus') {
                            $threadLink .= '&thread[]=link:' . $item->link;
                        } elseif ($params->get('tz_comment_type', 'disqus') == 'facebook') {
                            $threadLink .= '&urls[]=' . $item->link;
                        }
                    }
                    if ($params->get('tz_show_count_comment', 1) == 1) {
                        // From Disqus
                        if ($params->get('tz_comment_type', 'disqus') == 'disqus') {
                            if ($threadLink) {
                                $url = 'https://disqus.com/api/3.0/threads/list.json?api_secret='
                                    . $params->get('disqusApiSecretKey', '4sLbLjSq7ZCYtlMkfsG7SS5muVp7DsGgwedJL5gRsfUuXIt6AX5h6Ae6PnNREMiB')
                                    . '&forum=' . $params->get('disqusSubDomain', 'templazatoturials')
                                    . $threadLink . '&include=open';

                                $content = $fetch->get($url);

                                if ($content) {
                                    if ($body = json_decode($content->body)) {
                                        if ($responses = $body->response) {
                                            if (!is_array($responses)) {
                                                JError::raiseNotice('300', JText::_('COM_TZ_PORTFOLIO_DISQUS_INVALID_SECRET_KEY'));
                                            }
                                            if (is_array($responses) && count($responses)) {
                                                foreach ($responses as $response) {
                                                    $comments[$response->link] = $response->posts;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // From Facebook
                        if ($params->get('tz_comment_type', 'disqus') == 'facebook') {
                            if ($threadLink) {
                                $url = 'http://api.facebook.com/restserver.php?method=links.getStats'
                                    . $threadLink;
                                $content = $fetch->get($url);

                                if ($content) {
                                    if ($bodies = $content->body) {
                                        if (preg_match_all('/\<link_stat\>(.*?)\<\/link_stat\>/ims', $bodies, $matches)) {
                                            if (isset($matches[1]) && !empty($matches[1])) {
                                                foreach ($matches[1] as $val) {
                                                    $match = null;
                                                    if (preg_match('/\<url\>(.*?)\<\/url\>.*?\<comment_count\>(.*?)\<\/comment_count\>/msi', $val, $match)) {
                                                        if (isset($match[1]) && isset($match[2])) {
                                                            $comments[$match[1]] = $match[2];
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if ($params->get('tz_comment_type') == 'jcomment'): ?>
                            <?php
                            $comments = JPATH_SITE . '/components/com_jcomments/jcomments.php';
                            if (file_exists($comments)) {
                                require_once($comments);
                                if (class_exists('JComments')) {
                                    ?>
                                    <?php $item->commentCount = JComments::getCommentsCount((int)$item->contentid, 'com_tz_portfolio'); ?>
                                    <?php
                                }
                            }
                        endif;
                    }
                    if ($params->get('tz_show_count_comment', 1) == 1) {
                        if ($params->get('tz_comment_type', 'disqus') == 'disqus' ||
                            $params->get('tz_comment_type', 'disqus') == 'facebook'
                        ) {
                            if ($comments) {
                                if (array_key_exists($item->fullLink, $comments)) {
                                    $item->commentCount = $comments[$item->fullLink];
                                } else {
                                    $item->commentCount = 0;
                                }
                            } else {
                                $item->commentCount = 0;
                            }

                        }
                    }

                }
                return $items;
            }
        }
        if ($content == 'joomla_content') {
            $query = "SELECT ct.*,ct.id as arid, ct.hits as hit, ct.title as artitle, ct.alias as aralias, cat.title as category_title, us.name as created_by_user, cat.alias as category_alias
                                     FROM #__content ct LEFT JOIN #__categories cat ON(ct.catid = cat.id)
                                     LEFT JOIN #__users us On(ct.created_by = us.id) where
                                    $where ";
            $db->setQuery($query);
            $items = $db->loadObjectList();
            $param_com = JComponentHelper::getComponent('com_content')->params;
            if ($items) {
                if ($content == 'joomla_content') {
                    foreach ($items as $item) {
                        $item->text = $item->introtext;
                        JPluginHelper::importPlugin('content');
                        $results = $dispatcher->trigger('onContentPrepare', array('com_content.article', &$item, &$param_com, 0));
                        $item->introtext = $item->text;
                        $item->event = new stdClass();
                        $results = $dispatcher->trigger('onContentAfterTitle', array('com_content.article', &$item, &$param_com, 0));
                        $item->event->afterDisplayTitle = trim(implode("\n", $results));
                        $results = $dispatcher->trigger('onContentBeforeDisplay', array('com_content.article', &$item, &$param_com, 0));
                        $item->event->beforeDisplayContent = trim(implode("\n", $results));
                        $results = $dispatcher->trigger('onContentAfterDisplay', array('com_content.article', &$item, &$param_com, 0));
                        $item->event->afterDisplayContent = trim(implode("\n", $results));
                        $item->title = $item->artitle;
                        $item->media = null;
                        $item->hit = $item->hits;
                        $item->intro = $item->introtext;
                        $item->category = $item->category_title;
                        $item->author = $item->created_by_user;
                        $item->slug = $item->arid . ':' . $item->aralias;
                        $item->catslug = $item->catid . ':' . $item->category_alias;
                        $item->link = JRoute::_(ContentHelperRoute::getArticleRoute($item->slug, $item->catslug));
                        if ($item->images) {
                            $images = new JRegistry;
                            $images->loadString($item->images);
                            $images = json_decode($item->images);
                            $item->image = $images->image_intro;
                            $item->image_full = $images->image_fulltext;
                        } else {
                            $item->image = null;
                        }
                    }
                    return $items;
                }
            }
        }
    }
}

?>
