<?php
/*------------------------------------------------------------------------

# TZ Portfolio Extension

# ------------------------------------------------------------------------

# author    DuongTVTemPlaza

# copyright Copyright (C) 2012 templaza.com. All Rights Reserved.

# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL

# Websites: http://www.templaza.com

# Technical Support:  Forum - http://templaza.com/Forum

-------------------------------------------------------------------------*/

// no direct access
defined('_JEXEC') or die;
require_once JPATH_SITE . '/components/com_content/helpers/route.php';

jimport('joomla.application.component.model');
$url = JURI::base();

abstract class modTzMultiSlideshowHelper
{
    public static function getItemsSlideshow(&$params)
    {
        $db = JFactory::getDbo();
        $catids = $params->get('categories');
        $catid = implode(",", $catids);
        $order = $params->get('order');
        $orderby = $params->get('orderby');
        $limit = $params->get('limit');

        $query = "SELECT *,ct.id as arid, ct.title as artitle, ct.alias as aralias, cat.alias as category_alias
            FROM #__content ct LEFT JOIN #__categories cat ON(ct.catid = cat.id)
            WHERE ct.catid IN($catid) AND ct.state = 1  ORDER BY ct.$orderby $order LIMIT $limit
            ";
        $db->setQuery($query);
        $items = $db->loadObjectList();
        if ($items) {
            foreach ($items as $item) {
                $item->title = $item->artitle;
                $item->intro = $item->introtext;
                $item->slug = $item->arid . ':' . $item->aralias;
                $item->catslug = $item->catid . ':' . $item->category_alias;
                $item->link = JRoute::_(ContentHelperRoute::getArticleRoute($item->slug, $item->catslug));
                $item->intro = modTzMultiSlideshowHelper::rip_tags($item->introtext);
                if ($item->images) {
                    $images = new JRegistry;
                    $images->loadString($item->images);
                    $item->images;
                    $images = json_decode($item->images);
                    $item->image_thumb = $images->image_intro;
                    $item->image = $images->image_fulltext;
                }
            }
            return $items;
        }
        return false;
    }

    public static function rip_tags($string)
    {

        // ----- remove HTML TAGs -----
        $string = preg_replace('/<[^>]*>/', ' ', $string);

        // ----- remove control characters -----
        $string = str_replace("\r", '', $string); // --- replace with empty space
        $string = str_replace("\n", ' ', $string); // --- replace with space
        $string = str_replace("\t", ' ', $string); // --- replace with space

        // ----- remove multiple spaces -----
        $string = trim(preg_replace('/ {2,}/', ' ', $string));

        return $string;

    }


}

?>
