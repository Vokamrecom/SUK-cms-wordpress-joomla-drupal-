(function (a) {
    a.BigVideo = function (e) {
        var q = {useFlashForFirefox: true, forceAutoplay: false, controls: true, doLoop: false};
        var k = this, u, C = "#big-video-vid", o = a('<div id="big-video-wrap"></div>'), y = a(""), d = 16 / 9, h = 0, l = 0.8, v = false, b = false, g = false, s = false, c = false, A = [], r, w;
        var B = a.extend({}, q, e);
        var x = navigator.userAgent.toLowerCase();
        var j = x.indexOf("firefox") != -1;
        if (B.useFlashForFirefox && (j)) {
            VideoJS.options.techOrder = ["flash"]
        }
        function z() {
            var E = a(window).width();
            var F = a(window).height();
            var D = E / F;
            if (D < d) {
                if (w === "video") {
                    u.width(F * d).height(F);
                    a(C).css("top", 0).css("left", -(F * d - E) / 2).css("height", F);
                    a(C + "_html5_api").css("width", F * d);
                    a(C + "_flash_api").css("width", F * d).css("height", F)
                } else {
                    a("#big-video-image").css({width: "auto", height: F, top: 0, left: -(F * d - E) / 2})
                }
            } else {
                if (w === "video") {
                    u.width(E).height(E / d);
                    a(C).css("top", -(E / d - F) / 2).css("left", 0).css("height", E / d);
                    a(C + "_html5_api").css("width", "100%");
                    a(C + "_flash_api").css("width", E).css("height", E / d)
                } else {
                    a("#big-video-image").css({width: E, height: "auto", top: -(E / d - F) / 2, left: 0})
                }
            }
        }

        function t() {
            var D = '<div id="big-video-control-container">';
            D += '<div id="big-video-control">';
            D += '<a href="#" id="big-video-control-play"></a>';
            D += '<div id="big-video-control-middle">';
            D += '<div id="big-video-control-bar">';
            D += '<div id="big-video-control-bound-left"></div>';
            D += '<div id="big-video-control-progress"></div>';
            D += '<div id="big-video-control-track"></div>';
            D += '<div id="big-video-control-bound-right"></div>';
            D += "</div>";
            D += "</div>";
            D += '<div id="big-video-control-timer"></div>';
            D += "</div>";
            D += "</div>";
            a("body").append(D);
            a("#big-video-control-container").css("display", "none");
            a("#big-video-control-track").slider({animate: true, step: 0.01, slide: function (F, E) {
                b = true;
                a("#big-video-control-progress").css("width", (E.value - 0.16) + "%");
                u.currentTime((E.value / 100) * u.duration())
            }, stop: function (F, E) {
                b = false;
                u.currentTime((E.value / 100) * u.duration())
            }});
            a("#big-video-control-bar").click(function (E) {
                u.currentTime((E.offsetX / a(this).width()) * u.duration())
            });
            a("#big-video-control-play").click(function (E) {
                E.preventDefault();
                f("toggle")
            });
            u.on("timeupdate", function () {
                if (!b && (u.currentTime() / u.duration())) {
                    var E = u.currentTime();
                    var G = Math.floor(E / 60);
                    var H = Math.floor(E) - (60 * G);
                    if (H < 10) {
                        H = "0" + H
                    }
                    var F = u.currentTime() / u.duration() * 100;
                    a("#big-video-control-track").slider("value", F);
                    a("#big-video-control-progress").css("width", (F - 0.16) + "%");
                    a("#big-video-control-timer").text(G + ":" + H + "/" + h)
                }
            })
        }

        function f(D) {
            var E = D || "toggle";
            if (E === "toggle") {
                E = g ? "pause" : "play"
            }
            if (E === "pause") {
                u.pause();
                a("#big-video-control-play").css("background-position", "-16px");
                g = false
            } else {
                if (E === "play") {
                    u.play();
                    a("#big-video-control-play").css("background-position", "0");
                    g = true
                }
            }
        }

        function n() {
            u.play();
            a("body").off("click", n)
        }

        function m() {
            r++;
            if (r === A.length) {
                r = 0
            }
            p(A[r])
        }

        function p(D) {
            a(C).css("display", "block");
            w = "video";
            u.src(D);
            g = true;
            if (c) {
                a("#big-video-control-container").css("display", "none");
                u.volume(0);
                doLoop = true
            } else {
                a("#big-video-control-container").css("display", "block");
                u.volume(l);
                doLoop = false
            }
            a("#big-video-image").css("display", "none");
            a(C).css("display", "block")
        }

        function i(E) {
            a("#big-video-image").remove();
            u.pause();
            a(C).css("display", "none");
            a("#big-video-control-container").css("display", "none");
            w = "image";
            var D = a('<img id="big-video-image" src=' + E + " />");
            o.append(D);
            a("#big-video-image").imagesLoaded(function () {
                d = a("#big-video-image").width() / a("#big-video-image").height();
                z()
            })
        }

        k.init = function () {
            if (!v) {
                a("body").prepend(o);
                var D = B.forceAutoplay ? "autoplay" : "";
                u = a('<video id="' + C.substr(1) + '" class="video-js vjs-default-skin" preload="auto" data-setup="{}" ' + D + " webkit-playsinline></video>");
                u.css("position", "absolute");
                o.append(u);
                u = _V_(C.substr(1), {controls: false, autoplay: true, preload: "auto"});
                if (B.controls) {
                    t()
                }
                z();
                v = true;
                g = false;
                if (B.forceAutoplay) {
                    a("body").on("click", n)
                }
                a("#big-video-vid_flash_api").attr("scale", "noborder").attr("width", "100%").attr("height", "100%");
                a(window).resize(function () {
                    z()
                });
                u.on("loadedmetadata", function (G) {
                    if (document.getElementById("big-video-vid_flash_api")) {
                        d = document.getElementById("big-video-vid_flash_api").vjs_getProperty("videoWidth") / document.getElementById("big-video-vid_flash_api").vjs_getProperty("videoHeight")
                    } else {
                        d = a("#big-video-vid_html5_api").prop("videoWidth") / a("#big-video-vid_html5_api").prop("videoHeight")
                    }
                    z();
                    var F = Math.round(u.duration());
                    var E = Math.floor(F / 60);
                    var H = F - E * 60;
                    if (H < 10) {
                        H = "0" + H
                    }
                    h = E + ":" + H
                });
                u.on("ended", function () {
                    if (B.doLoop) {
                        u.currentTime(0);
                        u.play()
                    }
                    if (s) {
                        m()
                    }
                })
            }
        };
        k.show = function (F, D) {
            if (D === undefined) {
                D = {}
            }
            c = D.ambient === true;
            if (c || D.doLoop) {
                B.doLoop = true
            }
            if (typeof(F) === "string") {
                var E = F.substring(F.lastIndexOf(".") + 1);
                if (E === "jpg" || E === "gif" || E === "png") {
                    i(F)
                } else {
                    if (D.altSource && navigator.userAgent.toLowerCase().indexOf("firefox") > -1) {
                        F = D.altSource
                    }
                    p(F);
                    s = false
                }
            } else {
                A = F;
                r = 0;
                p(A[r]);
                s = true
            }
        };
        k.getPlayer = function () {
            return u
        };
        k.triggerPlayer = function (D) {
            f(D)
        }
    }
})(jQuery);