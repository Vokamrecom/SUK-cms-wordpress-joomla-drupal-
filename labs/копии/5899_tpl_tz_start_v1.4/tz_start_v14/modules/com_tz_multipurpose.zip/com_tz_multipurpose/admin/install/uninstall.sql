DROP TABLE IF EXISTS `#__tz_multipurpose_fields`,
 `#__tz_multipurpose_groupfield`
, `#__tz_multipurpose_groups`;
