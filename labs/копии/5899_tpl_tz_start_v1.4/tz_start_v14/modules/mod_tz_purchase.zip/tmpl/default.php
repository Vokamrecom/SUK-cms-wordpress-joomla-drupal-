<?php
/*------------------------------------------------------------------------

# TZ Extension

# ------------------------------------------------------------------------

# author    DuongTVTemPlaza

# copyright Copyright (C) 2012 templaza.com. All Rights Reserved.

# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL

# Websites: http://www.templaza.com

# Technical Support:  Forum - http://templaza.com/Forum

-------------------------------------------------------------------------*/

defined('_JEXEC') or die();

if($list):

    $doc    = JFactory::getDocument();
    if($params -> get('enable_jquery',0)):
        $doc -> addScript(JUri::base().'/modules/mod_tz_purchase/js/jquery-1.9.1.min.js');
    endif;
    $doc -> addScript(JUri::base().'/modules/mod_tz_purchase/js/jquery.flexslider-min.js');
    $doc -> addStyleSheet(JUri::base().'/modules/mod_tz_purchase/css/flexslider.css');
    $doc -> addStyleSheet(JUri::base().'/modules/mod_tz_purchase/css/style.css');

?>
    <div class="employee<?php echo $moduleclass_sfx;?> TzEmployee carousel">
        <div class="flexslider">
            <ul class="slides">
                <?php foreach($list as $item):?>
                <li>
                    <div class="slide">
                        <div class="image">
                            <img src="<?php echo JUri::root().$item -> employee_image;?>"/>
                            <div class="bg_image"></div>
                        </div>
                        <div class="info">
                            <span class="name"><?php echo $item -> employee_name;?></span>
                            <span class="career"><?php echo $item -> employee_career;?></span>
                        </div>
                    </div>
                </li>
                <?php endforeach;?>
            </ul>
        </div>
    </div>
    <script>
        <?php
            $options    = new stdClass();

            //Default Option
            $options -> slideshow = 'false';
            $options -> animationLoop = 'false';
            $options -> controlNav = 'false';
            $options -> directionNav = 'false';
            $options -> pausePlay = 'false';

            if($params -> get('slideshow',1)):
                $options -> slideshow = 'true';
            endif;

            if($params -> get('animationLoop',1)):
                $options -> animationLoop = 'true';
            endif;

            if($params -> get('controlNav',0)):
                $options -> controlNav = 'true';
            endif;

            if($params -> get('directionNav',1)):
                $options -> directionNav = 'true';
            endif;

            if($params -> get('slideshowSpeed',7000)):
                $options -> slideshowSpeed = $params -> get('slideshowSpeed',7000);
            endif;

            if($params -> get('animationSpeed',600)):
                $options -> animationSpeed = $params -> get('animationSpeed',600);
            endif;

            if($params -> get('pausePlay',0)):
                $options -> pausePlay = 'true';
            endif;

            if($params -> get('pauseText','Pause')):
                $options -> pauseText = '"'.$params -> get('pauseText','Pause').'"';
            endif;

            if($params -> get('playText','Play')):
                $options -> playText = '"'.$params -> get('playText','Play').'"';
            endif;

            if($params -> get('itemWidth',207)):
                $options -> itemWidth = $params -> get('itemWidth',207);
                $doc -> addStyleDeclaration('.TzEmployee .flexslider .image img{width: '.$options -> itemWidth.'px;}');
            endif;

            if($params -> get('minSlides',1)):
                $options -> minItems = $params -> get('minSlides',1);
            endif;

            if($params -> get('maxSlides',5)):
                $options -> maxItems = $params -> get('maxSlides',5);
            endif;

            if($params -> get('itemMargin',3)):
                $options -> itemMargin = $params -> get('itemMargin',3);
            endif;
        ?>
        jQuery('.TzEmployee .flexslider').flexslider({
            animation: "slide",
            slideshow: <?php echo $options -> slideshow;?>,
            animationLoop: <?php echo $options -> animationLoop;?>,
            controlNav: <?php echo $options -> controlNav;?>,
            directionNav: <?php echo $options -> directionNav;?>,
            slideshowSpeed: <?php echo $options -> slideshowSpeed;?>,
            animationSpeed: <?php echo $options -> animationSpeed;?>,
            pausePlay: <?php echo $options -> pausePlay;?>,
            pauseText: <?php echo $options -> pauseText;?>,
            playText: <?php echo $options -> playText;?>,
            itemWidth: <?php echo $options -> itemWidth; ?>,
            itemMargin: <?php echo $options -> itemMargin;?>,
            minItems: <?php echo $options -> minItems;?>,
            maxItems: <?php echo $options -> maxItems;?>,
            mousewheel: true,
            start: function(slider){
              jQuery('body').removeClass('loading');
                if(slider.find(".info")){
                    slider.find('.info').width(slider.find(".image").outerWidth());
                }
                if(slider.find('.flex-direction-nav')){
//                    slider.find('.flex-direction-nav').insertAfter(jQuery('.TzEmployee .flexslider'));
                    slider.find('.flex-direction-nav li a').css('top',slider.find(".image").outerHeight(true)/2);
                }
            }
          });
    </script>
<?php endif;?>