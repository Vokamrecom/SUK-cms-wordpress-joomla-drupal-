<?php
/**
 * Created by PhpStorm.
 * User: Thuong
 * Date: 5/7/14
 * Time: 11:31 AM
 */

defined('JPATH_BASE') or die;
include_once (JPATH_BASE) . '/components/com_tz_multipurpose/libraries/core/defines.php';
include_once (JPATH_BASE) . '/components/com_tz_multipurpose/libraries/core/tzmultipurpose.php';

if (!version_compare(JVERSION,'3.0','ge')) {
    JHtml::addIncludePath(JPATH_ADMINISTRATOR.'/components/com_tz_multipurpose/libraries/cms/html');
}
jimport('joomla.form.formfield');
jimport('joomla.html.editor');

JHtml::_('behavior.tooltip');
JHtml::_('formbehavior.chosen', 'select');
if(!version_compare(JVERSION, '3.7', 'ge')) {
    JHtml::_('behavior.framework');
    JHtml::_('behavior.formvalidation');
}else{
    JHtml::_('behavior.formvalidator');
}
JHtml::_('behavior.modal', 'a.modal');
JHtml::_('bootstrap.tooltip');
class JFormFieldTzMultipurpose extends JFormField {

    protected $type = 'TzMultipurpose';
    protected $head = false;

    // getLabel() left out

    public function getField($field) {
        $db		= JFactory::getDbo();
        $query	= $db->getQuery(true);
        $query -> select('*');
        $query -> from('#__tz_multipurpose_fields');
        $query -> where('id = '.$field);
        $db -> setQuery($query);
        $items = $db -> loadObjectList();

        return $items;
    }

    public function getInput() {
        $doc = JFactory::getDocument();
        if(!$this -> head) {
            if (!version_compare(JVERSION, '3.0', 'ge')) {
                $doc->addScript(JUri::root(true) . '/modules/mod_tz_multipurpose/admin/js/jquery-1.9.1.min.js');
                $doc->addScript(JUri::root(true) . '/modules/mod_tz_multipurpose/admin/js/jquery-noconflict.js');
            }
            $doc->addScript(JUri::root(true) . '/modules/mod_tz_multipurpose/admin/js/base64.js');
            $doc->addScript(JUri::root(true) . '/modules/mod_tz_multipurpose/admin/js/jquery-ui.min.js');
            $doc->addScript(JUri::root(true) . '/modules/mod_tz_multipurpose/admin/js/tzmultipurpose.js');
            $doc->addStyleSheet(JUri::root(true) . '/modules/mod_tz_multipurpose/admin/css/style.css');
            $this -> head   = true;
        }
        $db = JFactory::getDbo();
        $query  = $db -> getQuery(true);
        $query -> select('*');
        $query -> from('#__tz_multipurpose_groups');
        $db->setQuery($query);
        $items = $db -> loadObjectList();

        $value_item = 0;
        $html = '';
        $html .= '<a class="btn_add">'.JText::_('TZ_MULTIPURPOSE_ADD_NEW').'</a>';
//        $html .= '<a class="btn_data">'.JText::_('TZ_MULTIPURPOSE_ADD_NEW').'</a>';

        $html .= '<label id="select-lbl" name="tz_select_group">'.JText::_('MOD_TZ_MULTIPURPOSE_SELECT_GROUP_LABEL').'</label>';
        $html .= '<select id="tz_select_group" name="tz_select_group">';
//        $html .= '<option value="">Select Group Fields</option>';
//        foreach($items as $item) {
//            $html .= '<option value="'.$item -> id.'" >'.$item -> name.'</option>';
//        }
        $html .= '</select>';

        /// code get html field
        $html = $html.' <div class="control-group fields">';
        $html = $html.'<div id="tz-form-multipurpose" class="tz_form_multi"></div>';
        $html = $html.'</div>';


        ////// save html
        $html = $html.' <div class="control-group save">';
        $html = $html.'<button class="btn btn-success" type="button" id="' . $this->prefix . 'button_save">' . JText::_('JAPPLY') . '</button>';
        $html = $html.'<button class="btn" type="button" id="' . $this->prefix . 'button_cancel">' . JText::_('MOD_TZ_MULTIPURPOSE_RESET') . '</button>';
        $html = $html.' </div>';

//        $html = $html.'<div id="tz-table-multipurpose" class="tz_table_multi"></div>';
        $html = $html.'<div id="tz-table-multi" class="tz_table_multi">';
        $value  = $this -> value;
        if($value) {
            foreach($value as $key => $item) {
                $html .='<div class="tz_multipurpose_item">';
                $arr        = (array)$item;
                $group_id   = $arr['group'];
                $html .= '<div class="move tz_group_id">Move</div>';
                $html .= '<div class="edit tz_group_id" name="" value="'.$group_id.'">Edit</div>';
                $html .= '<input class="tz_group_id" type="hidden" name="" value="'.$group_id.'">';
                $html .= '<div class="delete tz_group_id" name="" value="'.$group_id.'">Delete</div>';
                foreach($arr as $n => $value_field) {
                    $html .='<div class="tz_item_child">';
                        if($n != 'group'){
                            if(is_numeric($n)) {
                                $field = $this -> getField($n);
                                foreach($field as $key => $value) {
                                    $html .='<div class="tz_field_name" data-id="'.$n.'">'.$value->title.'</div>';
                                    $html .='<div class="tz_field_value">'.$value_field;
                                    $html .='<input class="tz_fieldvalue data-id'.$n.'" type="hidden" value="'.$value_field.'" data-id="'.$n.'">';
                                    $html .='</div>';
                                }
                            }else {
                                $id_field_link = (int)$n;
                                $field = $this -> getField($id_field_link);
                                foreach($field as $key => $value) {
                                    $html .='<div class="tz_field_name" data-id="'.$n.'">'.$value->title.'</div>';
                                    $html .='<div class="tz_field_value">'.$value_field;
                                    $html .='<input class="tz_fieldvalue data-id'.$n.'" type="hidden" value="'.$value_field.'" data-id="'.$n.'">';
                                    $html .='</div>';
                                }
                            }
                        }
                    $html .='</div>';
                }
                $html .='</div>';
            }
        }
        $html = $html.'</div>';
        $html = $html.'<input type="hidden" id="tz_multi_hidden" name="'.$this->name.'"/>';
        return $html;
    }
}