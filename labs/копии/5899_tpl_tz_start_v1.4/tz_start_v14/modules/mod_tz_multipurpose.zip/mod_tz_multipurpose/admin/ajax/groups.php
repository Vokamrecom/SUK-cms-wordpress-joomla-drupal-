<?php
if( $_REQUEST["name"] )
{
    $name = $_REQUEST['name'];
    echo "Welcome ". $name;
}
?>